```
docker_compose_flags="-d" HTTPS_PORT=25700 AWS_SECRET_ACCESS_KEY="..." sh setup.sh
```